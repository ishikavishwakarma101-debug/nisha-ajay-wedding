NISHA & AJAY — WEDDING INVITATION V4

This version keeps the website structure and typography as real HTML/CSS,
but uses the two supplied watercolor illustrations in the exact sections
requested by the user.

FILES
-----
index.html
style.css
script.js
assets/wedding-couple.png
assets/schoolmates.png

IMAGE PLACEMENT
---------------
1. The previous CSS wedding-couple illustration has been replaced by:
   assets/wedding-couple.png

2. The previous CSS schoolmates illustration has been replaced by:
   assets/schoolmates.png

The supplied illustrations are not regenerated or altered.

RUN IN VS CODE
--------------
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Install "Live Server".
4. Right-click index.html.
5. Choose "Open with Live Server".

GITHUB PAGES
------------
Upload the complete folder contents while preserving the assets folder.
Then:
Settings -> Pages -> Deploy from a branch -> main -> /root -> Save

No paid domain is required.
